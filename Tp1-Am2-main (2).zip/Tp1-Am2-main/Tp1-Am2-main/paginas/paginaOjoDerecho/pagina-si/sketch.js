const total_imagenes = 30;
const cols = 6;
const rows = 5; 

let imagenes = [];
let links = [];

let cellWidth, cellHeight;

function preload() {
  for (let i = 1; i <= total_imagenes; i++) {
    imagenes.push(loadImage(`assets/img/self${i}.jpg`));
    links.push('https://ejemplo.com/' + i); // Cambia por tus URLs reales
  }
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  calculateCellSize();

  // Link para volver a la página principal
  const volverLink = createA('../../../index.html', 'Volver a la página principal');
  volverLink.position(20, 20);
  volverLink.style('font-size', '20px');
  volverLink.style('color', '#000');
  volverLink.style('text-decoration', 'none');
}

function draw() {
  let idx = 0;
  for(let row = 0; row < rows; row++){
    for(let col = 0; col < cols; col++){
      if(idx >= imagenes.length) break; // CORREGIDO

      let x = col * cellWidth;
      let y = row * cellHeight;

      image(imagenes[idx], x, y, cellWidth, cellHeight);
      idx++;
    }
  }
  

  // Añadir un enlace para volver a la página principal
  // Texto centrado en pantalla
  fill(255,0,0); // Color del texto (puedes cambiarlo)
  textAlign(CENTER, CENTER);
  textSize(70); // Tamaño del texto
  text("quizás no estamos tan solos como pensamos", width / 2, height / 2);
}

function mousePressed(){
    let col = floor(mouseX / cellWidth);
    let row = floor(mouseY / cellHeight);

    if(col >= 0 && col < cols && row >= 0 && row < rows){
        let idx = row * cols + col;
        if(idx < imagenes.length){
            openPopup(links[idx]);
        }
    }
}

function windowResized() {
  calculateCellSize();
  resizeCanvas(windowWidth, windowHeight);
}

function calculateCellSize() {
  cellWidth = width / cols;
  cellHeight = height / rows;
}

function openPopup(url) {
  // Tamaño deseado
  const w = 800;
  const h = 600;
  // Centrar la ventana en la pantalla
  const left = (window.screen.width / 2) - (w / 2);
  const top = (window.screen.height / 2) - (h / 2);

  window.open(
    url,
    '_blank',
    `width=${w},height=${h},left=${left},top=${top},resizable=yes,scrollbars=yes`
  );
}