

    // Coordenadas y dimensiones del recuadro negro principal
    let boxX, boxY, boxW, boxH, boxRadius = 16;

    // "No" botón (dentro del recuadro negro)
    let noX, noY, noW, noH, noRadius = 12;

    // "Sí" botón (fuera del recuadro negro, a la derecha)
    let siX, siY, siW, siH, siRadius = 16;

    function setup() {
      createCanvas(windowWidth, windowHeight);

      // Centro del canvas:
      boxW = 400;
      boxH = 100;
      boxX = (windowWidth - boxW) / 2;
      boxY = (windowHeight - boxH) / 2;

      // Dimensiones del botón NO (dentro del cuadro negro, izquierda)
      noW = 100;
      noH = 40;
      noX = boxX + 20;
      noY = boxY + boxH - noH - 20;

      // Dimensiones del botón SÍ (fuera del cuadro negro, a la derecha)
      siW = 120;
      siH = 50;
      siX = boxX + boxW + 20;  // 20 px a la derecha del recuadro negro
      siY = boxY + boxH - siH - 10; // Alineado aproximadamente con el NO
    }

    function draw() {
      background('#d3d3d3'); // gris claro

      // ---------- DIBUJAR EL RECUADRO NEGRO PRINCIPAL ----------
      noStroke();
      fill(0); // negro
      rect(boxX, boxY, boxW, boxH, boxRadius);

      // ---------- TEXTO DENTRO DEL RECUADRO NEGRO ----------
      fill(255); // blanco
      textSize(24);
      textAlign(LEFT, TOP);
      text('te sentís sol (elija una opción)?', boxX + 20, boxY + 20);

      // ---------- DIBUJAR BOTÓN "NO" DENTRO DEL RECUADRO ----------
      fill('#d3d3d3'); // gris claro para el botón NO
      stroke(0);
      strokeWeight(2);
      rect(noX, noY, noW, noH, noRadius);

      // Texto "no" centrado en el botón gris
      noStroke();
      fill(0); // texto negro
      textSize(20);
      textAlign(CENTER, CENTER);
      text('no', noX + noW / 2, noY + noH / 2);

      // ---------- DIBUJAR BOTÓN "SÍ" FUERA DEL RECUADRO ----------
      fill('#ff0000'); // rojo vivo
      stroke(0);
      strokeWeight(2);
      rect(siX, siY, siW, siH, siRadius);

      // Texto "si" centrado en el botón rojo
      noStroke();
      fill(255); // blanco
      textSize(24);
      textAlign(CENTER, CENTER);
      text('sí', siX + siW / 2, siY + siH / 2);
    }

    function mousePressed() {
      // Verificar si se hizo clic dentro del botón "no"
      if (
        mouseX >= noX && mouseX <= noX + noW &&
        mouseY >= noY && mouseY <= noY + noH
      ) {
        // Redirigir a la página de destino para "no"
        // Ejemplo: cambiar 'pagina_no.html' por la ruta real
        window.location.href = '';
      }

      // Verificar si se hizo clic dentro del botón "sí"
      if (
        mouseX >= siX && mouseX <= siX + siW &&
        mouseY >= siY && mouseY <= siY + siH
      ) {
        // Redirigir a la página de destino para "sí"
        // Ejemplo: cambiar 'pagina_si.html' por la ruta real
        window.location.href = '../pagina-si/index.html';
      }
    }

    function windowResized() {
      // Ajustar el tamaño del canvas al redimensionar la ventana
      resizeCanvas(windowWidth, windowHeight);

      // Recalcular las posiciones del recuadro y botones
      boxX = (windowWidth - boxW) / 2;
      boxY = (windowHeight - boxH) / 2;
      noX = boxX + 20;
      noY = boxY + boxH - noH - 20;
      siX = boxX + boxW + 20;
      siY = boxY + boxH - siH - 10;

    }