let imgFondo;



const urls = [
  'https://archive.org',
  'https://www.wikipedia.org',
  'https://archive.org/details/texts',
  'https://openlibrary.org',
  'https://www.gutenberg.org',
  'https://www.europeana.eu',
  'https://www.loc.gov',
  'https://www.nasa.gov/multimedia/imagegallery',
  'https://www.wikimedia.org',
  'https://data.gov',
  'https://www.kaggle.com/datasets',
  'https://github.com/awesomedata/awesome-public-datasets',
  'https://www.reddit.com/r/datasets/',
  'https://www.data.gov.uk',
  'https://www.data.gov.au',
  'https://catalog.data.gov/dataset?q=&sort=views_recent+desc',
  'https://arxiv.org/',
  'https://www.zenodo.org',
  'https://figshare.com',
  'https://www.khanacademy.org',
  'https://www.hathitrust.org/',
  'https://www.biodiversitylibrary.org',
  'https://www.worldcat.org',
  'https://www.census.gov/data.html',
  'https://www.fao.org/faostat/en/#home',
  'https://www.who.int/data',
  'https://www.imf.org/en/Data',
  'https://www.worldbank.org/en/data',
  'https://www.un.org/en/databases',
  'https://www.statista.com',
  'https://www.ons.gov.uk',
  'https://www.bls.gov/data/',

]
function preload() {
  imgFondo = loadImage('../imagenes/windows-wallpaper.jpg');
}

function setup() {
      // 1) Crear canvas y posicionarlo en (0,0)
      const cnv = createCanvas(windowWidth, windowHeight);
      cnv.position(0, 0);
      cnv.style('z-index', '-1'); // para que el canvas quede por detrás de los <a>

      // 2) Para cada URL, creamos un <a> y lo posicionamos dentro del canvas
      for (let i = 0; i < urls.length; i++) {
        // 2.1 Creamos el elemento <a> con la clase "enlace"
        const link = createA(urls[i], urls[i], '_blank');
        link.class('enlace'); 
        // Lo agregamos al body, pero aún no asignamos posición.
        link.style('font-size', '20px');
        link.style('color', 'black');
        link.style('text-decoration', 'none');
        link.style('position', 'absolute'); // Necesario para poder posicionarlo con .position()
        link.style("text-shadow", "2px 2px 4px rgba(0, 0, 0, 0.5)");
        // 2.2 Medimos su tamaño real en DOM (offsetWidth/offsetHeight)
        //    Éstas propiedades solo están disponibles tras haber insertado el link en el DOM.
        const lw = link.elt.offsetWidth;
        const lh = link.elt.offsetHeight;

        // 2.3 Calculamos coordenadas aleatorias asegurando que quepa completamente
        const x = random(0, windowWidth - lw);
        const y = random(0, windowHeight - lh);

        // 2.4 Finalmente ubicamos el enlace
        link.position(x, y);
      }
      const bachHome = createA('../../../index.html', 'Back to Home');
    }
function draw() {
  imageMode(CENTER);
  image(imgFondo, width / 2, height / 2, width, height);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}