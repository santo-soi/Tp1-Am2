const logo_size = 100;

const plataformas = [
  { name: 'Google', url: "https://www.google.com", img: "logos/google.svg" },
  { name: 'Facebook', url: "https://www.facebook.com", img: "logos/facebook.svg" },
  { name: 'Twitter', url: "https://www.twitter.com", img: "logos/x.svg" },
  { name: 'Instagram', url: "https://www.instagram.com", img: "logos/instagram.svg" },
  { name: 'Baidu', url: "https://www.baidu.com", img: "logos/baidu.svg" },
  { name: 'BeReal', url: "https://www.bereal.com", img: "logos/bereal.svg" },
  { name: 'LinkedIn', url: "https://www.linkedin.com", img: "logos/linkedin.svg" },
  { name: 'TikTok', url: "https://www.tiktok.com", img: "logos/tiktok.svg" },
  { name: 'YouTube', url: "https://www.youtube.com", img: "logos/youtube.svg" },
  { name: 'Pinterest', url: "https://www.pinterest.com", img: "logos/pinterest.svg" },
  { name: 'Snapchat', url: "https://www.snapchat.com", img: "logos/snapchat.svg" },
  { name: 'DuckDuckGo', url: "https://www.duckduckgo.com", img: "logos/duckduckgo.svg" },
  { name: 'Ebay', url: "https://www.ebay.com", img: "logos/ebay.svg" },
  { name: 'Ecosia', url: "https://www.ecosia.org", img: "logos/ecosia.svg" },
  {name: 'Mercado Pago', url: "https://www.mercadopago.com", img: "logos/mercadopago.svg" },
  {name: 'Netflix', url: "https://www.netflix.com", img: "logos/netflix.svg" },
  {name: 'TripAdvisor', url: "https://www.tripadvisor.com", img: "logos/tripadvisor.svg" },
  {name: 'Spotify', url: "https://www.spotify.com", img: "logos/spotify.svg" },
  {name: 'Twitch', url: "https://www.twitch.tv", img: "logos/twitch.svg" },
  {name: 'Uber', url: "https://www.uber.com", img: "logos/uber.svg" },
  {name: 'Walmart', url: "https://www.walmart.com", img: "logos/walmart.svg" },
  {name: 'Yandex', url: "https://www.yandex.com", img: "logos/yandexcloud.svg" },
]

let bgImg; 

function preload() {
  bgImg = loadImage("fondo.jpg");
}

function setup() {
  
  const cnv = createCanvas(windowWidth, windowHeight);
  cnv.position(0, 0);
  cnv.style('z-index', '-1');
  //creamos el link 
  plataformas.forEach(plataforma => {
    const link = createA(plataforma.url,'', '_blank');
    link.attribute('target', '_blank');
    link.style('position', 'absolute');
    //creamos la imagen del logo 
    const logo = createImg(plataforma.img, plataforma.name);
    logo.size(logo_size, logo_size);
    logo.parent(link);
    //calculamos la posicion aleatoria del logo
    const w1 = logo.elt.offsetWidth;
    const h1 = logo.elt.offsetHeight;
    // Aseguramos que el logo no se salga de la pantalla
    const x = random(0, windowWidth - w1);
    const y = random(0, windowHeight - h1);
    //posicionamos el logo
    link.position(x, y);
  });
  //link para volver a la pagina principal
  const backLink = createA('../../../index.html', 'Volver a la página principal', '_self');
}

function draw() {
  image(bgImg, 0, 0, width, height);

      noStroke();
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(62);
      text('Great choice\nAsí se hace', width / 2, height / 2);
}

function windowResized() { 
  resizeCanvas(windowWidth, windowHeight);
  // Reposicionar los enlaces al redimensionar la ventana
  selectAll('a').forEach(link => {
    const logo = link.child();
    const w1 = logo.elt.offsetWidth;
    const h1 = logo.elt.offsetHeight;
    const x = random(0, windowWidth - w1);
    const y = random(0, windowHeight - h1);
    link.position(x, y);
  });
}