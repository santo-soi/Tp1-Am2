let img;
let makeInternet, notMakeInternet;

function preload() {
  img = loadImage('imagenes/i-want-you.png');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  //eligieron si hacer internet rizomatico
  makeInternet = createA('makeInternet/makeInternet.html', 'Make Internet Rizomatic Again');
  makeInternet.style('font-size', '50px');
  
  //eligieron no hacer internet rizomatico
  notMakeInternet = createA('notMake/notMake.html', 'Not Make Internet Rizomatic Again');
  notMakeInternet.style('font-size', '30px');
  
  //volver a la pagina principal
  bachHome = createA('../../index.html', 'Back to Home');
  bachHome.style('font-size', '20px');
  positionLinks();
}

function draw() {
  background(150);
  imageMode(CENTER);
  image(img, width/2, height/2, 600, height);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  positionLinks();
}

function positionLinks() {
  makeInternet.position(width * 0.7, height * 0.4);
  notMakeInternet.position(width * 0.1, height * 0.4);
  bachHome.position(width * 0.01, height * 0.01);
}